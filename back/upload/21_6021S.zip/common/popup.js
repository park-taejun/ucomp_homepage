

function openWindow(target_url,width_size,height_size)
{
 var R_URL="";
 var farwindow=null;
  R_URL =target_url;
    farwindow=window.open('','open_win','width=1,height=1,left=3000,top=3000,scrollbars=yes');
                if (farwindow !=null) 
                {
    farwindow.close();
    farwindow=window.open('','open_win','width='+eval(width_size)+',height='+eval
(height_size)+',left=10,top=10,scrollbars=yes ');
             farwindow.location.href=R_URL;
    farwindow.focus();
                }
        }